# Gently

Desktop Plasma Theme

Changelog:

Icons:

media.svg

window.svg